module.exports = {
  default: 'info',

  'growi:routes:login-passport': 'debug',
  'growi:service:PassportService': 'debug',
};
