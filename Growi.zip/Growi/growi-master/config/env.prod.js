module.exports = {
  NODE_ENV: 'production',
  // FORMAT_NODE_LOG: false, // default: true
};
