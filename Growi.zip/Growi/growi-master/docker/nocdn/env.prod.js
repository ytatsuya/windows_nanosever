module.exports = {
  NODE_ENV: 'production',
  NO_CDN: true,
  // FORMAT_NODE_LOG: false,
};
